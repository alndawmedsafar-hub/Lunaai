import itertools
import requests
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# کارگەی گەورەی ٣٠ کلیلییەکەی LumaAI (Gemini + Groq + OpenRouter + Cohere)
massive_api_pool = itertools.cycle([
    # 1. کلیلەکانی Google AI Studio (10 کلیل)
    {"type": "gemini", "key": "AQ.Ab8RN6JuDGXeTH7KNB1DArpZh2G9fPMNKCOLNjpsRnFqBehMoQ"},
    {"type": "gemini", "key": "AQ.Ab8RN6IgwvXLLr8P6CqRJimtJ6HBqeyXbzfeHVtCynVyDeP60A"},
    {"type": "gemini", "key": "AQ.Ab8RN6KrVjgDwA8s5wCSsDtcVOI4eq06GLl5o7JBuVdoeuKoTw"},
    {"type": "gemini", "key": "AQ.Ab8RN6LZ-lYAFpOuMw_A6Xo0ATDC5_jl8ZzrkvoPa2oClXSA7Q"},
    {"type": "gemini", "key": "AQ.Ab8RN6KxJ-s-mi7rdwy7lA3RGyxvFKH9b7gmI6oAV2KLl6z2Ug"},
    {"type": "gemini", "key": "AQ.Ab8RN6LBYqKQnbX2pGGIvaR2mhzfhSpcytLSzoR_2Unb9bOHJg"},
    {"type": "gemini", "key": "AQ.Ab8RN6JwDQ-zIWA8JCeg6EEtaeT_VdmPsn5Dhm2n9B4qf-ibNA"},
    {"type": "gemini", "key": "AQ.Ab8RN6LaCVwlXLg_hJ6W3sXiztwkbORn49-d0c6bOBZtx0e3BA"},
    {"type": "gemini", "key": "AQ.Ab8RN6I_MZ51SbcndjnLpr9F1n1V71IEDCygs9lBZHHu33zuDQ"},
    {"type": "gemini", "key": "AQ.Ab8RN6JtCtzYhxTnhm5hfIxScIPZzlV8Ci4qsteNC8zxj9Vw-g"},
    
    # 2. کلیلەکانی Groq (9 کلیل)
    {"type": "groq", "key": "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"},
    {"type": "groq", "key": "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"},
    {"type": "groq", "key": "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"},
    {"type": "groq", "key": "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"},
    {"type": "groq", "key": "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"},
    {"type": "groq", "key": "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"},
    {"type": "groq", "key": "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"},
    {"type": "groq", "key": "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"},
    {"type": "groq", "key": "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"},

    # 3. کلیلەکانی OpenRouter (10 کلیل)
    {"type": "openrouter", "key": "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"},
    {"type": "openrouter", "key": "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"},
    {"type": "openrouter", "key": "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"},
    {"type": "openrouter", "key": "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"},
    {"type": "openrouter", "key": "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"},
    {"type": "openrouter", "key": "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"},
    {"type": "openrouter", "key": "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"},
    {"type": "openrouter", "key": "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"},
    {"type": "openrouter", "key": "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"},
    {"type": "openrouter", "key": "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"},

    # 4. کلیلی Cohere (کلیلی ژمارە ٣٠)
    {"type": "cohere", "key": "1Ld6cyFBEcX7rDmQBwXZZb07APyc5uQjyJhNK3Tn"}
])

def call_luma_factory(prompt):
    total_attempts = 30
    for _ in range(total_attempts):
        item = next(massive_api_pool)
        provider = item["type"]
        key = item["key"]
        
        try:
            if provider == "gemini":
                url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={key}"
                res = requests.post(url, json={"contents": [{"parts": [{"text": prompt}]}]})
                if res.status_code == 200:
                    return res.json()['candidates'][0]['content']['parts'][0]['text']
                    
            elif provider == "groq":
                url = "https://api.groq.com/openai/v1/chat/completions"
                headers = {"Authorization": f"Bearer {key}"}
                payload = {"model": "llama3-8b-8192", "messages": [{"role": "user", "content": prompt}]}
                res = requests.post(url, headers=headers, json=payload)
                if res.status_code == 200:
                    return res.json()['choices'][0]['message']['content']

            elif provider == "openrouter":
                url = "https://openrouter.ai/api/v1/chat/completions"
                headers = {"Authorization": f"Bearer {key}"}
                payload = {"model": "deepseek/deepseek-chat", "messages": [{"role": "user", "content": prompt}]}
                res = requests.post(url, headers=headers, json=payload)
                if res.status_code == 200:
                    return res.json()['choices'][0]['message']['content']

            elif provider == "cohere":
                url = "https://api.cohere.ai/v1/generate"
                headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
                payload = {"model": "command", "prompt": prompt, "max_tokens": 300}
                res = requests.post(url, headers=headers, json=payload)
                if res.status_code == 200:
                    return res.json()['generations'][0]['text']
                    
            if res.status_code in [429, 403]:
                continue
        except Exception:
            continue
            
    return "❌ هەموو کلیلەکانی کارگە سەرقاڵن، تکایە کەمێک چاوەڕێ بکە!"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message', '')
    ai_response = call_luma_factory(user_message)
    return jsonify({'response': ai_response})

import os

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 7860))
    app.run(host='0.0.0.0', port=port)
